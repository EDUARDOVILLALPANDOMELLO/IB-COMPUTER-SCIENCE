
/*
	ENCRIPTAR 

	ORDENAR LISTA
	-- TRES INTENTOS
	-- SALIR (ADMIN)
	GENERAR RECIBO 
	--MÉTODO ESTRELLAS
	--TOTAL EN CARRITO
	PARAG  O ALV

	-- SI NO EXISTE EL PRODUCTO
	-- ELIMINAR DEL CARRITO 
	--SI EL CARRITO ESTÁ VACIO
	FECHA

*/


import java.io.*;
import java.util.*;
import org.json.simple.*;
import org.json.simple.parser.*;
public class Carrito{
	public static int LOGIN_ATTEMPTS = 0;
	private static String FILE_CONTENTS;
	public static JSONArray JSON_ITEMS;
	public static JSONArray JSON_USERS;
	public static JSONArray JSON_ADMINS;
	public static JSONArray JSON_CART;
	public static int USER_ID;
	public static boolean IS_ADMIN;
	public static boolean IS_LOGGED_IN = false;
	public static String NOMBRE_USUARIO = null;
	public static JSONArray JSON_CART_ITEMS = new JSONArray();

	public static Scanner TECLADO = new Scanner(System.in); 

	public static void main (String args[]){
		parseJSONfn();
		LoginPrompt();
		menu();
	}
	public static void menu(){
		while(IS_LOGGED_IN){
			if(IS_ADMIN){
				productAdd();
			}
			else {
				showItems(); 
			}
		}
	}

	public static void parseJSONfn(){
		try{
			JSONParser PARSER = new JSONParser();
			JSONObject JSON_GET_OBJECT = (JSONObject) PARSER.parse(new FileReader("Informacion.json"));
			JSON_ITEMS = (JSONArray) JSON_GET_OBJECT.get("PRODUCTOS");
			JSON_USERS = (JSONArray) JSON_GET_OBJECT.get("USUARIOS");
			JSON_ADMINS = (JSONArray) JSON_GET_OBJECT.get("ADMINS");
			JSON_CART = (JSONArray) JSON_GET_OBJECT.get("CARRITO");
		} catch (ParseException ex){
			ex.printStackTrace();
		} catch (IOException ex){
			ex.printStackTrace();
		}
	}

	public static void LoginPrompt(){
		while(IS_LOGGED_IN == false && LOGIN_ATTEMPTS <3){
			System.out.println("");
			System.out.println("> BIENVENIDO \t [1] INICIAR SESION \t [2] REGISTRARSE \t [3] ADMIN");
			System.out.print(">> ");
			int LOGIN_SELEC = TECLADO.nextInt();
			System.out.println("");
			System.out.println(""); 
			if(LOGIN_SELEC == 1){
				userLogin();
			}
			else if(LOGIN_SELEC == 2){
				userAdd();
			}else if (LOGIN_SELEC == 3) {
				adminLogin();
			} else {
				System.out.println("Datos incorrectos, intenta nuevamente");
			}	
			LOGIN_ATTEMPTS++; 
		}
		System.out.println(" ");
		System.out.println(" ");
	}


	public static void userLogin(){
		Scanner TECLADO = new Scanner(System.in);
		System.out.println("> INICIAR SESION: Ingresa tus datos");
		System.out.print(">> USUARIO ");
		String USER = TECLADO.nextLine();
		System.out.print(">> CONTRASEÑA ");
		String PSSW = TECLADO.nextLine();
		//IS_LOGGED_IN = true;
		Iterator JSON_USERS_i = JSON_USERS.iterator();
		while(JSON_USERS_i.hasNext()){
			JSONObject JSON_USERS_ROW = (JSONObject) JSON_USERS_i.next();
			String USER_SAVE = (String) JSON_USERS_ROW.get("MAIL");
			String PSSW_SAVE = (String) JSON_USERS_ROW.get("CONTRASEÑA");
			if(USER_SAVE.equals(USER) && PSSW_SAVE.equals(PSSW)){
				IS_LOGGED_IN = true;
				break;
			}else{}
		}
	}

	public static void adminLogin(){
		Scanner TECLADO = new Scanner(System.in);
		System.out.println("");
		System.out.println("ADMINISTRADOR ");
		System.out.println("> INICIAR SESION: Ingresa tus datos");
		System.out.print(">> USUARIO ");
		String USER = TECLADO.nextLine();
		System.out.print(">> CONTRASEÑA ");
		String PSSW = TECLADO.nextLine();
		//IS_LOGGED_IN = true;
		Iterator JSON_ADMINS_i = JSON_ADMINS.iterator();
		while(JSON_ADMINS_i.hasNext()){
			JSONObject JSON_ADMINS_ROW = (JSONObject) JSON_ADMINS_i.next();
			String ADMINUSER_SAVE = (String) JSON_ADMINS_ROW.get("MAIL");
			String ADMINPSSW_SAVE = (String) JSON_ADMINS_ROW.get("CONTRASEÑA");
			if(ADMINUSER_SAVE.equals(USER) && ADMINPSSW_SAVE.equals(PSSW)){
				//USER_ID = USER_ID_SAVE;
				IS_ADMIN = true;
				IS_LOGGED_IN = true;
				break;
			}else{}
		}
		System.out.println(" ============================== ");
	}

	public static void userAdd(){
		Scanner TECLADO = new Scanner(System.in);
		System.out.println("> REGISTRARSE: Ingresa tu correo y contraseña");
		System.out.print(">> USUARIO: ");
		String NEW_USERNAME = TECLADO.nextLine();
		System.out.print(">> CONTRASEÑA: ");
		String NEW_PSSW = TECLADO.nextLine();

		JSONObject USER_OBJ = new JSONObject();
		USER_OBJ.put("MAIL", NEW_USERNAME);
		USER_OBJ.put("CONTRASEÑA", NEW_PSSW);
		JSON_USERS.add(USER_OBJ);
		JSONObject NEW_OBJ = new JSONObject();
		NEW_OBJ.put("USUARIOS", JSON_USERS);
		NEW_OBJ.put("PRODUCTOS", JSON_ITEMS);
		NEW_OBJ.put("ADMINS", JSON_ADMINS);
		try(FileWriter FILE_EDIT = new FileWriter("Informacion.json")){
			FILE_EDIT.write(NEW_OBJ.toJSONString());
			FILE_EDIT.flush();
		} catch( IOException ex ){
			ex.printStackTrace();
		}
		IS_LOGGED_IN = true;

	}
	public static void productAdd(){
		Scanner TECLADO = new Scanner(System.in);
		int NEW_PRICE = 0;
		String NEW_DESC = null;
		String NEW_NAME = null;
		int NEW_VALOR = 0;
		String NEW_CATEGORY = null;
		System.out.println("> AÑADIR PRODUCTOS: Ingresa la información del nuevo producto");
		try{
			System.out.print(">> PRECIO: \t");
			NEW_PRICE = TECLADO.nextInt();
			System.out.println("");
			
			System.out.print(">> DESCRIPCIÓN: \t");
			NEW_DESC = TECLADO.next();
			System.out.println("");
			
			System.out.print(">> NOMBRE: \t");
			NEW_NAME = TECLADO.next();
			System.out.println("");
			
			System.out.print(">> VALORACIONES: \t");
			NEW_VALOR= TECLADO.nextInt();
			System.out.println("");
			
			System.out.print(">> CATEGORÍA: \t");
			NEW_CATEGORY = TECLADO.next();
			System.out.println(""); 
		//}catch(InputMismatchException ex){

		//}
			JSONObject ADMIN_OBJ = new JSONObject();
			ADMIN_OBJ.put("ID", JSON_ITEMS.size()+1);
			ADMIN_OBJ.put("PRECIO", NEW_PRICE);
			ADMIN_OBJ.put("DESCRIPCION", NEW_DESC);
			ADMIN_OBJ.put("NOMBRE", NEW_NAME);
			ADMIN_OBJ.put("VALORACIONES", NEW_VALOR);
			ADMIN_OBJ.put("CATEGORIA", NEW_CATEGORY);
			JSON_ITEMS.add(ADMIN_OBJ);
			JSONObject NEW_OBJ = new JSONObject();
			NEW_OBJ.put("USUARIOS", JSON_USERS);
			NEW_OBJ.put("PRODUCTOS", JSON_ITEMS);
			NEW_OBJ.put("ADMINS", JSON_ADMINS);
			try(FileWriter FILE_EDIT = new FileWriter("Informacion.json")){
				FILE_EDIT.write(NEW_OBJ.toJSONString());
				FILE_EDIT.flush();
			} catch( IOException ex ){
				ex.printStackTrace();
			}

			System.out.println("SE HA AÑANDIDO UN PRODUCTO [S] PARA SALIR");
			char OPTION = TECLADO.next().charAt(0);
			if(OPTION == 'S'){
				System.out.println("qwertyui"); 
				//IS_LOGGED_IN = false; 
			}
			IS_LOGGED_IN = true;
		}catch(InputMismatchException ex){
			System.out.println("");
			System.out.println("");
			System.out.println("DATOS INCORRECTOS, INTÉNTALO NUEVAMENTE");
			System.out.println("");
			productAdd(); 
		}

	}

	public static void showItems(){
		Iterator JSON_ITEMS_i = JSON_ITEMS.iterator();
		Integer COUNT = 0;
		System.out.println("");
		System.out.println("");
		System.out.println("=====================================");
		System.out.println("============= PRODUCTOS =============");
		System.out.println("_____________________________________");
		System.out.println(" ");
		System.out.println("[ID] \t PRODUCTO \t PRECIO \t DESCRIPCION \t CATEGORÍA \t VALORACIONES");
		System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------------");
		while(JSON_ITEMS_i.hasNext()){
			JSONObject JSON_ITEM_OBJ = (JSONObject) JSON_ITEMS_i.next();
			COUNT++	;

			String ITEM_NAME = (String) JSON_ITEM_OBJ.get("NOMBRE");
			String ITEM_DESCRIPTION = (String) JSON_ITEM_OBJ.get("DESCRIPCION");

			int OBJ_ID = ((Long) JSON_ITEM_OBJ.get("ID")).intValue() + 1;
			int JSON_ITEM_VALORACIONES = ((Long) JSON_ITEM_OBJ.get("VALORACIONES")).intValue();
			System.out.println("["+OBJ_ID+"] \t "+JSON_ITEM_OBJ.get("NOMBRE")+" \t $"+JSON_ITEM_OBJ.get("PRECIO")+" \t \t"+JSON_ITEM_OBJ.get("DESCRIPCION")+" \t "+JSON_ITEM_OBJ.get("CATEGORIA")+ "\t "+renderStars(JSON_ITEM_VALORACIONES));
			System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------------");
		}
		Scanner TECLADO = new Scanner(System.in);
		System.out.println("  ");
		System.out.println("> [P] AGREGAR PRODUCTOS \t [C] MOSTRAR CARRITO");
		char SELECT_OP = TECLADO.next().charAt(0);
		if(SELECT_OP == 'P'){
			System.out.println("> SELECCIONE UN PRODUCTO... [0] PARA CANCELAR  ");
			int SELECT_ITEM_ID = TECLADO.nextInt()-1;
			addToCart(SELECT_ITEM_ID);
		} else if (SELECT_OP == 'C'){
			showCart();
		}
	}

	public static void showCart(){
		Scanner TECLADO = new Scanner(System.in);
		System.out.println("");
		System.out.println("=============== CARRITO ==============");
		System.out.println(""); 
		Iterator JSON_ITEMS_i = JSON_CART_ITEMS.iterator();
		int TOTAL_A_PAGAR = 0;
		if(JSON_CART_ITEMS.size() == 0){
			System.out.println("NO HAY PRODUCTOS EN TU CARRITO :(");
		} else {
			while(JSON_ITEMS_i.hasNext()){
				JSONObject JSON_ITEM_OBJ = (JSONObject) JSON_ITEMS_i.next();
				//String ITEM_NAME = (String) JSON_ITEM_OBJ.get("NOMBRE");
				//String ITEM_DESCRIPTION = (String) JSON_ITEM_OBJ.get("DESCRIPCION");
				int JSON_ITEM_PRECIO = ((Long) JSON_ITEM_OBJ.get("PRECIO")).intValue();
				int JSON_ITEM_VALORACIONES = ((Long) JSON_ITEM_OBJ.get("VALORACIONES")).intValue();
				TOTAL_A_PAGAR = TOTAL_A_PAGAR+JSON_ITEM_PRECIO;
				int OBJ_ID = ((Long) JSON_ITEM_OBJ.get("ID")).intValue() + 1;
				System.out.println("["+OBJ_ID+"] \t "+JSON_ITEM_OBJ.get("NOMBRE")+" \t $"+JSON_ITEM_OBJ.get("PRECIO")+" \t \t"+JSON_ITEM_OBJ.get("DESCRIPCION")+" \t "+JSON_ITEM_OBJ.get("CATEGORIA")+ "\t "+renderStars(JSON_ITEM_VALORACIONES));
				System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------------");
			}
			System.out.println("");
				System.out.println("=====================================================================================================================================================");
				System.out.println("TOTAL A PAGAR: \t $"+TOTAL_A_PAGAR);
				System.out.println("====================================================================================================================================================="); 
				System.out.println(""); 
			/*System.out.println("> [E] ELIMINAR PRODUCTOS \t [P] SEGUIR COMPRANDO \t [F] FINALIZAR COMPRA");
			char SELECT_OP = TECLADO.next().charAt(0);
			if(SELECT_OP == 'E'){

			} else if (SELECT_OP == 'P'){
				showItems();
			} else if (SELECT_OP == 'F'){

			}*/
		}
		System.out.println("> PULSE CUALQUIER TECLA PARA SEGUIR COMPRANDO \t \t [E] ELIMINAR PRODUCTOS \t [F] FINALIZAR COMPRA");
		char SELECT_OP = TECLADO.next().charAt(0);
		if(SELECT_OP == 'E'){
			System.out.println("");
			System.out.println(""); 
			System.out.println("> SELECCIONE UN PRODUCTO");
			System.out.println("");
			int ITEM_ID = TECLADO.nextInt();
			removeCart(ITEM_ID);

		} else if (SELECT_OP == 'F'){

		} else {
			showItems(); 
		}
	}

	public static void addToCart(int ITEM_ID){
		boolean ITEM_EXISTS = false;
		Iterator JSON_ITEMS_i = JSON_ITEMS.iterator();
		while(JSON_ITEMS_i.hasNext()){
			JSONObject JSON_ITEM_OBJ = (JSONObject) JSON_ITEMS_i.next();
			int JSON_ITEM_ID = ((Long) JSON_ITEM_OBJ.get("ID")).intValue();
			if(JSON_ITEM_ID == ITEM_ID){
				ITEM_EXISTS = true;
				int JSON_ITEM_ID_DISPALY = JSON_ITEM_ID+1;
				int JSON_ITEM_RATING = ((Long) JSON_ITEM_OBJ.get("VALORACIONES")).intValue();
				System.out.println("");
				System.out.println("Se ha añadido a tu carrito de compras... ");
				System.out.println("["+JSON_ITEM_ID_DISPALY+"] \t "+JSON_ITEM_OBJ.get("NOMBRE")+" \t $"+JSON_ITEM_OBJ.get("PRECIO")+" \t \t"+JSON_ITEM_OBJ.get("DESCRIPCION")+" \t "+JSON_ITEM_OBJ.get("CATEGORIA")+ "\t "+renderStars(JSON_ITEM_RATING));
				JSON_CART_ITEMS.add(JSON_ITEM_OBJ);
			}
		}
		if(ITEM_ID == 0){
			System.out.println("CANCELANDO...");
			System.out.println(""); 
		}
		else if(ITEM_EXISTS == false){
			System.out.println("EL PRODUCTO NO EXISTE, INTENTELO NUEVAMENTE"); 
			System.out.println("");
		}
	}
	
	public static void removeCart(int ITEM_ID){
		JSONArray NEW_JSON_CART_ITEMS = new JSONArray();
		Iterator JSON_CART_ITEMS_i = JSON_CART_ITEMS.iterator();
		while(JSON_CART_ITEMS_i.hasNext()){
			JSONObject JSON_CART_ITEM_OBJ = (JSONObject) JSON_CART_ITEMS_i.next();
			int JSON_CART_ITEM_ID = ((Long) JSON_CART_ITEM_OBJ.get("ID")).intValue();
			if(JSON_CART_ITEM_ID != ITEM_ID){
				NEW_JSON_CART_ITEMS.add(JSON_CART_ITEM_OBJ);
			}
		}
		JSON_CART_ITEMS = new JSONArray();
		JSON_CART_ITEMS = NEW_JSON_CART_ITEMS; 
	}

	public static String renderStars(int ESTRELLAS){
		int REMAINING = 5-ESTRELLAS;
		String RESULT_STARS = "";
		for(int i=0; i<ESTRELLAS; i++){
			RESULT_STARS = RESULT_STARS+"*";
		}
		for(int i=0; i<REMAINING; i++){
			RESULT_STARS = RESULT_STARS+"-";
		}
		//return "Hello workd";
		return RESULT_STARS;
	}

}

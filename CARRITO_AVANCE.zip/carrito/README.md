# JSON AND JAVA SHOPPING CART

An extendable shopping cart experience using JSON as a database. 

## JSON FILE STRUCTURE

* USUARIOS 
* PRODUCTOS
* CARRITOS
* ADMIN

## TO COMPILE
(FOR UNIX BASED SYSTEMS)

     sudo javac -cp ".:json-simple-1.jar" Carrito.java
     
## TO RUN 
(FOR UNIX BASED SYSTEMS)

     sudo java -cp ".:json-simple-1.jar" Carrito

## BOTH
    sudo javac -cp ".:json-simple-1.jar" Carrito.java && sudo java -cp ".:json-simple-1.jar" Carrito
